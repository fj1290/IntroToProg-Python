#-------------------------------------------------#
# Title: Managing a To Do list w/ Functions
# Dev:   DSmith
# Date:  November 5, 2016
# ChangeLog: NA
#-------------------------------------------------#


strFileName = "Todo.txt" #Name of file that stores To Do list
lstTodo = [] #Create empty list


class ListMgmt(): #Create class that contains list management functions

    @staticmethod
    def LoadList(filename):
        '''Loads contents of text file into a list'''
        file = open(filename,"r")

        for line in file:
            (t, p) = line.split(", ") #Add each file line to tuple
            dictFile = {"Task":t,"Priority":str(p).strip("\n")} #Add tuple data to a dict
            lstTodo.append(dictFile) #Add dict to list
        file.close() #Close file

    @staticmethod
    def DisplayList():
        '''Displays the list'''
        print("\n-------------To Do List-------------")
        for i in lstTodo:
            print("Task: " + i["Task"] + "; Priority: " + i["Priority"])
        print("------------------------------------")

    @staticmethod
    def ChangeList():
        '''Displays menu of options to change the list'''
        while(True): #Start loop for list changes
            print(
                "\nHere are your options:\n"
                "\t 1 = Add a task\n"
                "\t 2 = Remove a task\n"
                "\t 3 = Save the list and exit"
            )

            choice = input("Enter your choice (1-3): ") #Prompt user for action

            if(choice == "1"): #Add task
                strT = input("Enter the name of the task to add: ") #Task input
                strP = input("Enter the priority ('low', 'medium', 'high'): ") #Priority input
                dictInput={"Task":strT,"Priority":strP} #Add to a dict
                lstTodo.append(dictInput)  #Add dict to list

            elif(choice == "2"): #Remove task
                print("\n")
                check = True
                while (check == True):
                    for i in lstTodo:
                        print("\t" + str(lstTodo.index(i)) +
                              " = Task: " + i["Task"] +
                              "; Priority: " + i["Priority"]
                              )

                    intRemove = int(input("\nEnter the task-priority number to remove: "))

                    if (intRemove >= 0 and intRemove <len(lstTodo)): #Valid task to remove
                        lstTodo.pop(intRemove)
                        check = False
                    else: #Invalid task to remove
                        print("\n*** Error: Enter one of numbers shown. ***")
                        continue

            elif(choice == "3"): #Save list

                break

            else: #Invalid choice
               print("\n*** Error: Choice must be '1', '2', or '3'. ***")


    @staticmethod
    def SaveList(filename):
        '''Writes/saves the list to the text file'''
        file = open(filename, "w")

        for i in lstTodo:
            file.write(i["Task"] + ", " + i["Priority"] + "\n")  # Write list to file
        file.close()  # Close file
        print("\nList was saved to " + filename)  # Notify user of save


ListMgmt.LoadList(strFileName)
ListMgmt.DisplayList()
ListMgmt.ChangeList()
ListMgmt.SaveList(strFileName)

