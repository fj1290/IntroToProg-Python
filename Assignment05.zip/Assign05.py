'''
Title: IT FDN 100 A - Assignment 05
Author: D Smith
Desc:
1.	Create a text file called Todo.txt using the following data:
    Clean House,low
    Pay Bills,high
2.	When the program starts, load each row of data from the ToDo.txt text file into a Python dictionary.
3.	After you get a row of data stored in a Python dictionary, add the new “row” into a Python List object.
4.	Display the contents of the List to the user.
5.	Allow the user to Add or Remove tasks from the list using numbered choices.
6.	Save the data from the table into the Todo.txt file when the program exits.
'''

list = [] #Create empty list
file_r = open("Todo.txt","r") #Open file in read mode

for line in file_r:
    (t, p) = line.split(", ") #Add each file line to tuple
    dictFile = {"Task":t,"Priority":str(p).strip("\n")} #Add tuple data to a dict
    list.append(dictFile) #Add dict to list
file_r.close() #Close file

while(True): #Start loop for list changes
    print("\n-------------To Do List-------------")
    for i in list:
        print("Task: " + i["Task"] + "; Priority: " + i["Priority"])
    print(
        "------------------------------------"
        "\nHere are your options:\n"
        "\t 1 = Add a task\n"
        "\t 2 = Remove a task\n"
        "\t 3 = Save list to Todo.txt"
    )

    choice = input("Enter your choice (1-3): ") #Prompt user for action
    print("\n")

    if(choice == "1"): #Add task
        strT = input("Enter the name of the task to add: ") #Task input
        strP = input("Enter the priority ('low', 'medium', 'high'): ") #Priority input
        dictInput={"Task":strT,"Priority":strP} #Add to a dict
        list.append(dictInput)  #Add dict to list

    elif(choice == "2"): #Remove task
        check = True
        while (check == True):
            for i in list:
                print("\t" + str(list.index(i)) +
                      " = Task: " + i["Task"] +
                      "; Priority: " + i["Priority"]
                      )

            intRemove = int(input("\nEnter the task-priority number to remove: "))

            if (intRemove >= 0 and intRemove <len(list)): #Valid task to remove
                list.pop(intRemove)
                check = False
            else: #Invalid task to remove
                print("*** Error: Enter one of numbers shown. ***")
                continue

    elif(choice == "3"): #Save list
        file_w = open("Todo.txt", "w")  #Open file in write mode

        for i in list:
            file_w.write(i["Task"] + ", " + i["Priority"] + "\n")  #Write list to file
        file_w.close()  #Close file
        print("\nList was saved to Todo.txt.")  #Notify user of save

        break

    else: #Invalid choice
       print("*** Error: Choice must be '1', '2', or '3'. ***")




